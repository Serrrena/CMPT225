#include "LinkedList.h"

#include <iostream>
using namespace std;

int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	
	LinkedList list;
	list.add(14);
	list.add(20);
	list.add(26);

	list.printList(cout);
	cout << endl;

	LinkedList l2(list);
	l2.printList(cout);
	cout << endl;

	return 0;
}
